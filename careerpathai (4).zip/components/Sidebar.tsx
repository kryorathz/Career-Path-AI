import React from 'react';
import type { Page } from '../types';
import { DashboardIcon, DocumentIcon, BeakerIcon, ChatBubbleIcon, PencilSquareIcon, GlobeAltIcon, LogoIcon, ArrowLeftOnRectangleIcon } from './icons/Icons';
import { useAppContext } from '../App';
import { supabase, isSupabaseConfigured } from '../services/supabaseClient';


const Sidebar: React.FC = () => {
  const { activePage, setActivePage, analysis, session, clearUserData } = useAppContext();
  
  const handleLogout = async () => {
      if (supabase) {
        clearUserData();
        await supabase.auth.signOut();
      }
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <DashboardIcon />, requiresAnalysis: false },
    { id: 'resume-analyzer', label: 'Resume Analysis', icon: <DocumentIcon />, requiresAnalysis: false },
    { id: 'resume-builder', label: 'Resume Builder', icon: <PencilSquareIcon />, requiresAnalysis: true },
    { id: 'skill-diagnostic', label: 'Skill Diagnostic', icon: <BeakerIcon />, requiresAnalysis: true },
    { id: 'career-hub', label: 'Career Hub', icon: <GlobeAltIcon />, requiresAnalysis: false },
    { id: 'interview-prep', label: 'AI Career Coach', icon: <ChatBubbleIcon />, requiresAnalysis: true },
  ];

  return (
    <div className="w-64 bg-dark-purple-sidebar border-r border-dark-purple-card-border flex flex-col no-print">
      <div className="flex items-center justify-center h-20 border-b border-dark-purple-card-border px-6">
        <LogoIcon className="h-8 w-auto" />
      </div>
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navItems.map((item) => {
            const isDisabled = item.requiresAnalysis && !analysis;
            return (
              <a
                key={item.id}
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  if (!isDisabled) {
                    setActivePage(item.id as Page);
                  }
                }}
                className={`flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors duration-200 ${
                  activePage === item.id
                    ? 'bg-brand-purple-light text-white font-semibold'
                    : isDisabled 
                    ? 'text-light-purple-text-muted/50 cursor-not-allowed'
                    : 'text-light-purple-text-muted hover:bg-dark-purple-card hover:text-light-purple-text'
                }`}
                aria-disabled={isDisabled}
              >
                {React.cloneElement(item.icon, { className: 'w-5 h-5' })}
                <span className="ml-3">{item.label}</span>
              </a>
            )
        })}
      </nav>
      {isSupabaseConfigured && session && (
        <div className="px-4 py-6 border-t border-dark-purple-card-border">
            <p className="text-xs text-light-purple-text-muted truncate" title={session.user.email}>{session.user.email}</p>
            <button
                onClick={handleLogout}
                className="flex items-center w-full mt-4 px-4 py-2.5 text-sm font-medium rounded-lg text-light-purple-text-muted hover:bg-dark-purple-card hover:text-light-purple-text transition-colors duration-200"
            >
                <ArrowLeftOnRectangleIcon className="w-5 h-5" />
                <span className="ml-3">Log Out</span>
            </button>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
