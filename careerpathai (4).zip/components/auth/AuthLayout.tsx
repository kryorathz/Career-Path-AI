import React from 'react';
import Card from '../ui/Card';
import { LogoIcon } from '../icons/Icons';

interface AuthLayoutProps {
  title: string;
  children: React.ReactNode;
}

const AuthLayout: React.FC<AuthLayoutProps> = ({ title, children }) => {
  return (
    <div className="min-h-screen bg-dark-purple-bg flex flex-col justify-center items-center p-4 font-sans">
      <div 
          className="absolute inset-0 -z-10 h-full w-full bg-transparent" 
          style={{backgroundImage: 'radial-gradient(rgba(167, 139, 250, 0.1) 1px, transparent 1px)', backgroundSize: '16px 16px'}}
      ></div>
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <a href="#" className="inline-block" aria-label="Home">
            <LogoIcon className="h-10 w-auto" />
          </a>
        </div>
        <Card className="w-full">
          <h1 className="text-2xl font-bold text-center text-white mb-6">{title}</h1>
          {children}
        </Card>
      </div>
    </div>
  );
};

export default AuthLayout;
