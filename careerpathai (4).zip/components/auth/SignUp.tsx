import React, { useState } from 'react';
import AuthLayout from './AuthLayout';
import Button from '../ui/Button';
import Loader from '../ui/Loader';
import { supabase, isSupabaseConfigured } from '../../services/supabaseClient';
import { ExclamationTriangleIcon } from '../icons/Icons';

interface SignUpProps {
  onNavigateToLogin: () => void;
  onSignUpSuccess: (email: string) => void;
}

const SignUp: React.FC<SignUpProps> = ({ onNavigateToLogin, onSignUpSuccess }) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const isAuthDisabled = !isSupabaseConfigured;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (isAuthDisabled || !supabase) {
      setError("This application is not configured for user sign-ups. Please contact the administrator.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords don't match!");
      return;
    }
    setLoading(true);
    setError(null);

    try {
        const { data, error } = await supabase.auth.signUp({
            email,
            password,
            options: {
                data: {
                    full_name: fullName,
                }
            }
        });
        if (error) throw error;
        if (data.user) {
            onSignUpSuccess(email);
        } else {
            throw new Error("Sign up successful, but no user data returned. Please check your email for a verification link.");
        }
    } catch (error: any) {
        setError(error.error_description || error.message);
    } finally {
        setLoading(false);
    }
  };

  const inputClasses = "w-full p-3 bg-dark-purple-bg border border-dark-purple-card-border rounded mt-1 text-light-purple-text focus:ring-brand-purple focus:border-brand-purple disabled:opacity-50 disabled:cursor-not-allowed";

  return (
    <AuthLayout title="Create an account">
       {isAuthDisabled && (
        <div className="mb-4 text-sm text-amber-200 bg-amber-900/40 p-4 rounded-lg">
           <div className="text-left">
                <p className="font-semibold flex items-center">
                    <ExclamationTriangleIcon className="w-5 h-5 mr-2 flex-shrink-0" />
                    Action Required: Configure Authentication
                </p>
                <p className="mt-2 text-xs text-amber-200/80">
                    User sign-up is disabled. To fix this, please add the following environment variables in your project's settings:
                    <ul className="list-disc list-inside mt-2 font-mono bg-black/20 p-2 rounded">
                        <li>SUPABASE_URL</li>
                        <li>SUPABASE_ANON_KEY</li>
                    </ul>
                </p>
            </div>
        </div>
      )}
      {error && <p className="mb-4 text-center text-sm text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-sm font-medium text-light-purple-text-muted">Full Name</label>
          <input 
            type="text" 
            className={inputClasses} 
            value={fullName} 
            onChange={e => setFullName(e.target.value)} 
            required 
            placeholder="Your Name"
            disabled={loading || isAuthDisabled}
          />
        </div>
        <div>
          <label className="text-sm font-medium text-light-purple-text-muted">Email Address</label>
          <input 
            type="email" 
            className={inputClasses} 
            value={email} 
            onChange={e => setEmail(e.target.value)} 
            required
            placeholder="you@example.com"
            disabled={loading || isAuthDisabled}
          />
        </div>
        <div>
          <label className="text-sm font-medium text-light-purple-text-muted">Password</label>
          <input 
            type="password" 
            className={inputClasses} 
            value={password} 
            onChange={e => setPassword(e.target.value)} 
            required
            placeholder="Create a strong password (min. 6 characters)"
            disabled={loading || isAuthDisabled}
          />
        </div>
        <div>
          <label className="text-sm font-medium text-light-purple-text-muted">Confirm Password</label>
          <input 
            type="password" 
            className={inputClasses} 
            value={confirmPassword} 
            onChange={e => setConfirmPassword(e.target.value)} 
            required
            placeholder="Repeat password"
            disabled={loading || isAuthDisabled}
          />
        </div>
        <div className="flex items-center">
            <input
                id="agree"
                name="agree"
                type="checkbox"
                className="h-4 w-4 rounded border-gray-300 text-brand-purple focus:ring-brand-purple disabled:opacity-50"
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                required
                disabled={isAuthDisabled}
            />
            <label htmlFor="agree" className="ml-2 block text-xs text-light-purple-text-muted">
                I agree to the <a href="#" className="font-medium text-brand-purple hover:underline">Terms</a> and <a href="#" className="font-medium text-brand-purple hover:underline">Privacy Policy</a>.
            </label>
        </div>
        <Button type="submit" className="w-full" size="lg" disabled={!agreed || loading || isAuthDisabled}>
          {loading ? <><Loader /> Creating Account...</> : 'Create Account'}
        </Button>
      </form>
      
      <p className="mt-6 text-center text-sm text-light-purple-text-muted">
        Already have an account?{' '}
        <a href="#" onClick={(e) => { e.preventDefault(); onNavigateToLogin(); }} className="font-medium text-brand-purple hover:underline">
          Log in
        </a>
      </p>
    </AuthLayout>
  );
};

export default SignUp;