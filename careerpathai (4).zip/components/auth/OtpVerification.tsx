import React, { useState, useRef } from 'react';
import AuthLayout from './AuthLayout';
import Button from '../ui/Button';
import Loader from '../ui/Loader';
import { supabase, isSupabaseConfigured } from '../../services/supabaseClient';
import { ExclamationTriangleIcon } from '../icons/Icons';

interface OtpVerificationProps {
  email: string;
  onNavigateToLogin: () => void;
}

const OtpVerification: React.FC<OtpVerificationProps> = ({ email, onNavigateToLogin }) => {
  const [otp, setOtp] = useState<string[]>(new Array(6).fill(""));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const isAuthDisabled = !isSupabaseConfigured;

  const handleChange = (element: HTMLInputElement, index: number) => {
    if (isNaN(Number(element.value))) return;

    const newOtp = [...otp];
    newOtp[index] = element.value;
    setOtp(newOtp);

    // Focus next input
    if (element.nextSibling && element.value) {
      (element.nextSibling as HTMLInputElement).focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
    if (e.key === "Backspace" && !otp[index] && inputRefs.current[index - 1]) {
      inputRefs.current[index - 1]?.focus();
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
      e.preventDefault();
      if (isAuthDisabled || !supabase) {
        setError("This application is not configured for OTP verification. Please contact the administrator.");
        return;
      }
      
      const code = otp.join('');
      if(code.length !== 6) {
        setError("Please enter a valid 6-digit code.");
        return;
      }

      setLoading(true);
      setError(null);
      try {
        const { error } = await supabase.auth.verifyOtp({
            email,
            token: code,
            type: 'signup'
        });
        if (error) throw error;
        // The onAuthStateChange listener in App.tsx will handle redirecting to the dashboard.
        // We can navigate to login as a fallback if the user needs to log in again.
        alert("Verification successful! You will be logged in.");
      } catch (error: any) {
        setError(error.error_description || error.message);
      } finally {
        setLoading(false);
      }
  }

  return (
    <AuthLayout title="Verify your email">
       {isAuthDisabled && (
        <div className="mb-4 text-sm text-amber-200 bg-amber-900/40 p-4 rounded-lg">
           <div className="text-left">
                <p className="font-semibold flex items-center">
                    <ExclamationTriangleIcon className="w-5 h-5 mr-2 flex-shrink-0" />
                    Action Required: Configure Authentication
                </p>
                <p className="mt-2 text-xs text-amber-200/80">
                    Email verification is disabled. To fix this, please add the following environment variables in your project's settings:
                    <ul className="list-disc list-inside mt-2 font-mono bg-black/20 p-2 rounded">
                        <li>SUPABASE_URL</li>
                        <li>SUPABASE_ANON_KEY</li>
                    </ul>
                </p>
            </div>
        </div>
      )}
      <p className="text-center text-sm text-light-purple-text-muted mb-6">
        We've sent a 6-digit code to <span className="font-medium text-white">{email}</span>. Please enter it below to confirm your account.
      </p>
      {error && <p className="mb-4 text-center text-sm text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
      <form onSubmit={handleSubmit}>
        <div className="flex justify-center gap-2 mb-6">
          {otp.map((data, index) => (
            <input
              key={index}
              type="text"
              name="otp"
              maxLength={1}
              value={data}
              onChange={e => handleChange(e.target, index)}
              onKeyDown={e => handleKeyDown(e, index)}
              onFocus={e => e.target.select()}
              ref={el => { inputRefs.current[index] = el; }}
              className="w-12 h-14 text-center text-2xl font-bold bg-dark-purple-bg border border-dark-purple-card-border rounded text-white focus:ring-brand-purple focus:border-brand-purple disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={loading || isAuthDisabled}
            />
          ))}
        </div>
        <Button type="submit" className="w-full" size="lg" disabled={loading || isAuthDisabled}>
          {loading ? <><Loader /> Verifying...</> : 'Verify'}
        </Button>
      </form>
      <p className="mt-6 text-center text-sm text-light-purple-text-muted">
        Already verified?{' '}
        <button onClick={onNavigateToLogin} className="font-medium text-brand-purple hover:underline focus:outline-none">
          Log in
        </button>
      </p>
    </AuthLayout>
  );
};

export default OtpVerification;