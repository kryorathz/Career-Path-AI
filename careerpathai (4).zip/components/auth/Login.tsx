import React, { useState } from 'react';
import AuthLayout from './AuthLayout';
import Button from '../ui/Button';
import Loader from '../ui/Loader';
import { GoogleIcon, GithubIcon, LinkedinIcon, ExclamationTriangleIcon } from '../icons/Icons';
import { supabase, isSupabaseConfigured } from '../../services/supabaseClient';
import type { Provider } from '@supabase/supabase-js';

interface LoginProps {
  onNavigateToSignUp: () => void;
  onNavigateToForgotPassword: () => void;
}

const Login: React.FC<LoginProps> = ({ onNavigateToSignUp, onNavigateToForgotPassword }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const isAuthDisabled = !isSupabaseConfigured;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isAuthDisabled || !supabase) {
      setError("This application is not configured for user login. Please contact the administrator.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) throw error;
      // onAuthStateChange will handle navigation
    } catch (error: any) {
      setError(error.error_description || error.message);
    } finally {
      setLoading(false);
    }
  };
  
  const handleSocialLogin = async (provider: Provider) => {
    if (isAuthDisabled || !supabase) {
      setError("This application is not configured for social login. Please contact the administrator.");
      return;
    }
    setError(null);
    const { error } = await supabase.auth.signInWithOAuth({ provider });
    if (error) {
        setError(error.message);
    }
  }

  const inputClasses = "w-full p-3 bg-dark-purple-bg border border-dark-purple-card-border rounded mt-1 text-light-purple-text focus:ring-brand-purple focus:border-brand-purple disabled:opacity-50 disabled:cursor-not-allowed";

  return (
    <AuthLayout title="Log in to your account">
      {isAuthDisabled && (
        <div className="mb-4 text-sm text-amber-200 bg-amber-900/40 p-4 rounded-lg">
           <div className="text-left">
                <p className="font-semibold flex items-center">
                    <ExclamationTriangleIcon className="w-5 h-5 mr-2 flex-shrink-0" />
                    Action Required: Configure Authentication
                </p>
                <p className="mt-2 text-xs text-amber-200/80">
                    User sign-in is disabled. To fix this, please add the following environment variables in your project's settings:
                    <ul className="list-disc list-inside mt-2 font-mono bg-black/20 p-2 rounded">
                        <li>SUPABASE_URL</li>
                        <li>SUPABASE_ANON_KEY</li>
                    </ul>
                </p>
            </div>
        </div>
      )}
      {error && <p className="mb-4 text-center text-sm text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-sm font-medium text-light-purple-text-muted">Email Address</label>
          <input 
            type="email" 
            className={inputClasses} 
            value={email} 
            onChange={e => setEmail(e.target.value)} 
            required 
            placeholder="you@example.com"
            disabled={loading || isAuthDisabled}
          />
        </div>
        <div>
           <div className="flex justify-between items-center">
             <label className="text-sm font-medium text-light-purple-text-muted">Password</label>
             <a href="#" onClick={(e) => { e.preventDefault(); onNavigateToForgotPassword(); }} className="text-xs font-medium text-brand-purple hover:underline">Forgot Password?</a>
           </div>
          <input 
            type="password" 
            className={inputClasses} 
            value={password} 
            onChange={e => setPassword(e.target.value)} 
            required
            placeholder="••••••••"
            disabled={loading || isAuthDisabled}
          />
        </div>
        <Button type="submit" className="w-full" size="lg" disabled={loading || isAuthDisabled}>
          {loading ? <><Loader /> Logging In...</> : 'Log In'}
        </Button>
      </form>

      <div className="relative my-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-dark-purple-card-border"></div>
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="bg-dark-purple-card px-2 text-light-purple-text-muted">Or continue with</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
          <Button variant="secondary" className="flex items-center justify-center" onClick={() => handleSocialLogin('google')} disabled={isAuthDisabled}><GoogleIcon /></Button>
          <Button variant="secondary" className="flex items-center justify-center" onClick={() => handleSocialLogin('github')} disabled={isAuthDisabled}><GithubIcon /></Button>
          <Button variant="secondary" className="flex items-center justify-center" onClick={() => handleSocialLogin('linkedin')} disabled={isAuthDisabled}><LinkedinIcon /></Button>
      </div>
      
      <p className="mt-6 text-center text-sm text-light-purple-text-muted">
        Don't have an account?{' '}
        <a href="#" onClick={(e) => { e.preventDefault(); onNavigateToSignUp(); }} className="font-medium text-brand-purple hover:underline">
          Sign up
        </a>
      </p>
    </AuthLayout>
  );
};

export default Login;