import React, { useState } from 'react';
import AuthLayout from './AuthLayout';
import Button from '../ui/Button';
import Loader from '../ui/Loader';
import { supabase, isSupabaseConfigured } from '../../services/supabaseClient';
import { ExclamationTriangleIcon } from '../icons/Icons';

interface ForgotPasswordProps {
  onNavigateToLogin: () => void;
}

const ForgotPassword: React.FC<ForgotPasswordProps> = ({ onNavigateToLogin }) => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const isAuthDisabled = !isSupabaseConfigured;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isAuthDisabled || !supabase) {
      setError("This application is not configured for password recovery. Please contact the administrator.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin, // Redirects user back to the app after password reset
      });
      if (error) throw error;
      setSubmitted(true);
    } catch (error: any) {
      setError(error.error_description || error.message);
    } finally {
      setLoading(false);
    }
  };
  
  const inputClasses = "w-full p-3 bg-dark-purple-bg border border-dark-purple-card-border rounded mt-1 text-light-purple-text focus:ring-brand-purple focus:border-brand-purple disabled:opacity-50 disabled:cursor-not-allowed";

  return (
    <AuthLayout title="Forgot your password?">
      {isAuthDisabled && (
        <div className="mb-4 text-sm text-amber-200 bg-amber-900/40 p-4 rounded-lg">
           <div className="text-left">
                <p className="font-semibold flex items-center">
                    <ExclamationTriangleIcon className="w-5 h-5 mr-2 flex-shrink-0" />
                    Action Required: Configure Authentication
                </p>
                <p className="mt-2 text-xs text-amber-200/80">
                    Password recovery is disabled. To fix this, please add the following environment variables in your project's settings:
                    <ul className="list-disc list-inside mt-2 font-mono bg-black/20 p-2 rounded">
                        <li>SUPABASE_URL</li>
                        <li>SUPABASE_ANON_KEY</li>
                    </ul>
                </p>
            </div>
        </div>
      )}
      {submitted ? (
        <div className="text-center">
            <p className="text-light-purple-text-muted">If an account with that email exists, we've sent a password reset link to it.</p>
            <Button onClick={onNavigateToLogin} className="mt-6 w-full" variant="secondary">Back to Login</Button>
        </div>
      ) : (
        <>
            <p className="text-center text-sm text-light-purple-text-muted mb-6">Enter your email address and we'll send you a link to reset your password.</p>
            {error && <p className="mb-4 text-center text-sm text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                <label className="text-sm font-medium text-light-purple-text-muted">Email Address</label>
                <input 
                    type="email" 
                    className={inputClasses} 
                    value={email} 
                    onChange={e => setEmail(e.target.value)} 
                    required 
                    placeholder="you@example.com"
                    disabled={loading || isAuthDisabled}
                />
                </div>
                <Button type="submit" className="w-full" size="lg" disabled={loading || isAuthDisabled}>
                  {loading ? <><Loader/> Sending...</> : 'Send Reset Link'}
                </Button>
            </form>
            
            <p className="mt-6 text-center text-sm text-light-purple-text-muted">
                Remembered your password?{' '}
                <a href="#" onClick={(e) => { e.preventDefault(); onNavigateToLogin(); }} className="font-medium text-brand-purple hover:underline">
                Log in
                </a>
            </p>
        </>
      )}
    </AuthLayout>
  );
};

export default ForgotPassword;