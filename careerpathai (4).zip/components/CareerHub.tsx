import React, { useState, useRef, useEffect } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import { getCareerHubResponse } from '../services/geminiService';
import { saveChatMessage, getChatHistory } from '../services/databaseService';
import type { ChatMessage, Opportunity } from '../types';
import { SparklesIcon, GlobeAltIcon } from './icons/Icons';
import { useAppContext } from '../App';
import Loader from './ui/Loader';


const OpportunityTable: React.FC<{ opportunities: Opportunity[] }> = ({ opportunities }) => (
    <div className="mt-4 overflow-x-auto">
        <table className="min-w-full divide-y divide-brand-purple/20">
            <thead className="bg-dark-purple-bg">
                <tr>
                    <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-light-purple-text-muted uppercase tracking-wider">Title</th>
                    <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-light-purple-text-muted uppercase tracking-wider">Company / Provider</th>
                    <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-light-purple-text-muted uppercase tracking-wider">Location / Type</th>
                    <th scope="col" className="px-4 py-2 text-left text-xs font-medium text-light-purple-text-muted uppercase tracking-wider"></th>
                </tr>
            </thead>
            <tbody className="bg-dark-purple-card-border divide-y divide-brand-purple/20">
                {opportunities.map((op, index) => (
                    <tr key={index}>
                        <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-light-purple-text">{op.title}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-light-purple-text-muted">{op.companyOrProvider}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-light-purple-text-muted">
                           <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${op.type === 'Job' ? 'bg-sky-200 text-sky-800' : op.type === 'Internship' ? 'bg-emerald-200 text-emerald-800' : 'bg-amber-200 text-amber-800'}`}>
                              {op.type}
                           </span>
                           <span className="ml-2">{op.location}</span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-right text-sm font-medium">
                            <a href={op.url} target="_blank" rel="noopener noreferrer" className="text-brand-purple hover:text-violet-300">
                                View
                            </a>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
);


const CareerHub: React.FC = () => {
    const { analysis } = useAppContext();
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isHistoryLoading, setIsHistoryLoading] = useState(true);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const loadChat = async () => {
            setIsHistoryLoading(true);
            const history = await getChatHistory('hub');
            if (history && history.length > 0) {
                setMessages(history);
            } else {
                const initialMessageText = analysis 
                    ? "Welcome to the Career Hub! Based on your resume, I can help you find jobs, internships, or courses. What are you looking for?"
                    : "Welcome to the Career Hub! I can help you find jobs, internships, or courses. To get started, tell me about your interests, skills, or what kind of role you're looking for.";
                setMessages([{ sender: 'ai', text: initialMessageText }]);
            }
            setIsHistoryLoading(false);
        };
        loadChat();
    }, [analysis]);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!userInput.trim() || isLoading) return;

        const userMessage: ChatMessage = { sender: 'user', text: userInput };
        const newMessages: ChatMessage[] = [...messages, userMessage];
        setMessages(newMessages);
        setUserInput('');
        setIsLoading(true);

        try {
            await saveChatMessage('hub', userMessage);
            
            let messageToSend = userInput;
            if (analysis?.summary) {
                messageToSend = `(My resume summary for context: "${analysis.summary}"). User's request: ${userInput}`;
            }

            const { summary, opportunities, sources } = await getCareerHubResponse(messageToSend);
            const aiMessage: ChatMessage = { sender: 'ai', text: summary, opportunities, sources };
            setMessages(prev => [...prev, aiMessage]);
            await saveChatMessage('hub', aiMessage);

        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred.';
            const errorMsg: ChatMessage = { sender: 'ai', text: `Sorry, I encountered an error: ${errorMessage}` };
            setMessages(prev => [...prev, errorMsg]);
        } finally {
            setIsLoading(false);
        }
    };
    
    const quickActionClicked = (prompt: string) => {
        setUserInput(prompt);
    }

    return (
        <div className="max-w-4xl mx-auto">
            <div className="text-center">
                <GlobeAltIcon className="mx-auto h-12 w-12 text-brand-purple" />
                <h1 className="mt-4 text-3xl font-bold text-white">Career Hub</h1>
                <p className="mt-1 text-light-purple-text-muted">Your AI-powered gateway to jobs, internships, and courses.</p>
            </div>
            
            <Card className="mt-8">
                <div className="h-[65vh] flex flex-col">
                    <div className="flex-1 overflow-y-auto pr-4 -mr-4 space-y-4">
                        {isHistoryLoading ? (
                             <div className="flex justify-center items-center h-full">
                                <Loader />
                             </div>
                        ) : (
                          <>
                            {messages.map((msg, index) => (
                                <div key={index} className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                                    {msg.sender === 'ai' && (
                                        <div className="w-8 h-8 rounded-full bg-brand-purple flex items-center justify-center flex-shrink-0">
                                            <SparklesIcon className="w-5 h-5 text-dark-purple-bg" />
                                        </div>
                                    )}
                                    <div className={`p-3 rounded-lg w-full max-w-lg ${msg.sender === 'ai' ? 'bg-dark-purple-card-border text-light-purple-text' : 'bg-brand-purple text-dark-purple-bg'}`}>
                                        <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                                        
                                        {msg.opportunities && msg.opportunities.length > 0 && (
                                           <OpportunityTable opportunities={msg.opportunities} />
                                        )}

                                        {msg.sources && msg.sources.length > 0 && (
                                            <div className="mt-3 border-t border-brand-purple/20 pt-2">
                                                <h4 className="text-xs font-semibold mb-1">Sources:</h4>
                                                <div className="space-y-1">
                                                {msg.sources.map((source, i) => (
                                                    <a href={source.web.uri} key={i} target="_blank" rel="noopener noreferrer" className="block text-xs text-brand-purple/80 hover:underline truncate">
                                                        {source.web.title || source.web.uri}
                                                    </a>
                                                ))}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ))}
                            {isLoading && (
                                <div className="flex items-start gap-3">
                                     <div className="w-8 h-8 rounded-full bg-brand-purple flex items-center justify-center flex-shrink-0">
                                        <SparklesIcon className="w-5 h-5 text-dark-purple-bg" />
                                    </div>
                                    <div className="p-3 rounded-lg bg-dark-purple-card-border">
                                        <div className="flex items-center justify-center space-x-1">
                                           <span className="w-2 h-2 bg-light-purple-text-muted rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                           <span className="w-2 h-2 bg-light-purple-text-muted rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                           <span className="w-2 h-2 bg-light-purple-text-muted rounded-full animate-bounce"></span>
                                        </div>
                                    </div>
                                </div>
                            )}
                             {messages.length <= 1 && !isLoading && !isHistoryLoading && (
                                <div className="flex gap-2 justify-center pt-8">
                                    <Button size="sm" variant="secondary" onClick={() => quickActionClicked('Find remote software engineer jobs')}>Find SWE Jobs</Button>
                                    <Button size="sm" variant="secondary" onClick={() => quickActionClicked('Paid marketing internships for students')}>Find Internships</Button>
                                    <Button size="sm" variant="secondary" onClick={() => quickActionClicked('Free online courses for project management')}>Find Courses</Button>
                                </div>
                             )}
                            <div ref={messagesEndRef} />
                          </>
                        )}
                    </div>
                    <form onSubmit={handleSubmit} className="mt-6">
                        <div className="relative">
                            <textarea
                                value={userInput}
                                onChange={(e) => setUserInput(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter' && !e.shiftKey) {
                                        handleSubmit(e);
                                    }
                                }}
                                placeholder="e.g., 'Find paid internships in New York for marketing students'"
                                className="w-full p-3 pr-24 bg-dark-purple-bg border border-dark-purple-card-border text-light-purple-text rounded-lg focus:ring-brand-purple focus:border-brand-purple resize-none"
                                rows={2}
                                disabled={isLoading || isHistoryLoading}
                            />
                            <Button type="submit" className="absolute right-3 bottom-2.5" disabled={isLoading || !userInput.trim()}>
                                Send
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default CareerHub;
