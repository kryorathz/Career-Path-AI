import React, { useState, useMemo, useRef, useEffect } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import Loader from './ui/Loader';
import { generateSkillQuestions, evaluateAnswers, getSkillTutorResponseStream } from '../services/geminiService';
import { saveSkillDiagnostic, getChatHistory, saveChatMessage } from '../services/databaseService';
import type { SkillQuestion, DiagnosticFeedback, ChatMessage } from '../types';
import { BeakerIcon, ExclamationTriangleIcon, CheckCircleIcon, SparklesIcon, QuestionMarkCircleIcon, XMarkIcon } from './icons/Icons';
import { useAppContext } from '../App';

const SkillDiagnostic: React.FC = () => {
  const { analysis, setActivePage } = useAppContext();
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);
  const [questions, setQuestions] = useState<SkillQuestion[]>([]);
  const [userAnswers, setUserAnswers] = useState<(string | null)[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [feedback, setFeedback] = useState<DiagnosticFeedback | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isTutorOpen, setIsTutorOpen] = useState(false);

  const skillTopics = useMemo(() => {
    if (analysis?.skills) {
      return [...new Set(analysis.skills)].slice(0, 4);
    }
    return [];
  }, [analysis]);

  if (!analysis) {
    return (
        <Card className="text-center">
            <h2 className="text-xl font-bold text-white">Analyze Your Resume First</h2>
            <p className="mt-2 text-light-purple-text-muted">Upload your resume to get personalized skill diagnostics based on your experience.</p>
            <Button onClick={() => setActivePage('resume-analyzer')} className="mt-4">Go to Analyzer</Button>
        </Card>
    );
  }

  const startTest = async (skill: string) => {
    setIsLoading(true);
    setError(null);
    setFeedback(null);
    setQuestions([]);
    try {
      const fetchedQuestions = await generateSkillQuestions(skill, 5);
      setQuestions(fetchedQuestions);
      setUserAnswers(new Array(fetchedQuestions.length).fill(null));
      setCurrentQuestionIndex(0);
      setSelectedSkill(skill);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnswerSelect = (answer: string) => {
    const newAnswers = [...userAnswers];
    newAnswers[currentQuestionIndex] = answer;
    setUserAnswers(newAnswers);
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const submitTest = async () => {
    if (!selectedSkill) return;
    setIsLoading(true);
    setError(null);
    try {
        const result = await evaluateAnswers(questions, userAnswers);
        setFeedback(result);
        await saveSkillDiagnostic(selectedSkill, questions, userAnswers, result);
    } catch(err) {
        setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
        setIsLoading(false);
    }
  };
  
  const resetTest = () => {
      setSelectedSkill(null);
      setQuestions([]);
      setFeedback(null);
  }

  if (isLoading && !questions.length && !feedback) {
    return <Card className="flex flex-col items-center justify-center p-10"><Loader size="lg" className="text-brand-purple" /><p className="mt-4 text-light-purple-text-muted">Generating your skill test...</p></Card>;
  }

  if (feedback) {
    return <FeedbackDisplay feedback={feedback} onRetry={resetTest}/>;
  }

  if (questions.length > 0 && selectedSkill) {
    const question = questions[currentQuestionIndex];
    const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
    return (
      <>
        <Card className="max-w-2xl mx-auto">
          <h2 className="text-xl font-bold text-center text-white">Skill Diagnostic: {selectedSkill}</h2>
          
          <div className="mt-4">
              <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-light-purple-text">Question {currentQuestionIndex + 1} of {questions.length}</span>
              </div>
              <div className="w-full bg-dark-purple-card-border rounded-full h-2.5">
                  <div className="bg-brand-purple h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
              </div>
          </div>
          
          <div className="mt-8">
              <div className="flex justify-between items-start">
                  <p className="text-lg font-semibold text-white flex-1">{question.question}</p>
                  <Button variant="secondary" size="sm" onClick={() => setIsTutorOpen(true)}>
                      <QuestionMarkCircleIcon className="w-4 h-4 mr-1"/> Ask AI Tutor
                  </Button>
              </div>
              <div className="mt-4 space-y-3">
                  {question.options.map((option, index) => (
                      <button
                          key={index}
                          onClick={() => handleAnswerSelect(option)}
                          className={`w-full text-left p-4 border rounded-lg transition-colors ${
                              userAnswers[currentQuestionIndex] === option 
                              ? 'bg-brand-purple-light border-brand-purple ring-2 ring-brand-purple/50 text-white' 
                              : 'bg-dark-purple-bg border-dark-purple-card-border hover:bg-dark-purple-card-border text-light-purple-text'
                          }`}
                      >
                          {option}
                      </button>
                  ))}
              </div>
          </div>

          <div className="mt-8 flex justify-end">
              {currentQuestionIndex < questions.length - 1 ? (
                  <Button onClick={nextQuestion} disabled={!userAnswers[currentQuestionIndex]}>Next</Button>
              ) : (
                  <Button onClick={submitTest} disabled={isLoading || !userAnswers[currentQuestionIndex]}>
                      {isLoading ? <><Loader /> Submitting...</> : 'Submit & See Results'}
                  </Button>
              )}
          </div>
        </Card>
        {isTutorOpen && <TutorChatModal question={question.question} onClose={() => setIsTutorOpen(false)} />}
      </>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-white">Skill Diagnostic</h1>
        <p className="mt-1 text-light-purple-text-muted">Test your knowledge in skills identified from your resume.</p>
        
        {error && (
            <Card className="mt-6 bg-red-900/50 border-red-500/50">
                <div className="flex items-center">
                    <ExclamationTriangleIcon className="text-red-400"/>
                    <p className="ml-2 text-sm font-medium text-red-300">{error}</p>
                </div>
            </Card>
        )}

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            {skillTopics.map(skill => (
                 <Card key={skill} className="flex flex-col items-center justify-center p-8 text-center hover:shadow-2xl hover:-translate-y-1 transition-all">
                    <div className="p-4 bg-brand-purple-light rounded-full">
                       <BeakerIcon className="text-brand-purple w-8 h-8"/>
                    </div>
                    <h3 className="mt-4 text-lg font-semibold text-white">{skill}</h3>
                    <p className="mt-1 text-sm text-light-purple-text-muted">5 questions, ~5 minutes</p>
                    <Button onClick={() => startTest(skill)} className="mt-6" disabled={isLoading}>Start Test</Button>
                 </Card>
            ))}
        </div>
    </div>
  );
};


const FeedbackDisplay: React.FC<{feedback: DiagnosticFeedback, onRetry: () => void}> = ({feedback, onRetry}) => {
    return (
        <Card className="max-w-3xl mx-auto">
            <div className="text-center">
                <h2 className="text-2xl font-bold text-white">Test Complete!</h2>
                <p className="text-6xl font-bold mt-4" style={{color: feedback.score > 70 ? '#34d399' : feedback.score > 40 ? '#f59e0b' : '#ef4444' }}>
                    {feedback.score}%
                </p>
                <p className="text-light-purple-text-muted">Your Score</p>
            </div>
            
            <div className="mt-8">
                <h3 className="text-lg font-semibold flex items-center text-white">
                    <SparklesIcon className="text-brand-purple" />
                    <span className="ml-2">AI Feedback</span>
                </h3>
                <p className="mt-2 text-light-purple-text bg-dark-purple-bg p-4 rounded-lg border border-dark-purple-card-border">{feedback.feedback}</p>
            </div>

            <div className="mt-8">
                 <h3 className="text-lg font-semibold text-white">Review Your Answers</h3>
                 <ul className="mt-3 space-y-4">
                     {feedback.correctAnswers.map((item, index) => (
                         <li key={index} className="p-3 bg-dark-purple-bg rounded-lg border border-dark-purple-card-border">
                             <p className="font-medium text-sm text-light-purple-text">{item.question}</p>
                             <div className="mt-2 flex items-center text-sm text-emerald-400">
                                <CheckCircleIcon />
                                <span className="ml-2">Correct Answer: {item.answer}</span>
                             </div>
                         </li>
                     ))}
                 </ul>
            </div>

            <div className="mt-8 flex justify-center">
                <Button onClick={onRetry} variant="secondary">Take Another Test</Button>
            </div>
        </Card>
    );
};

const TutorChatModal: React.FC<{question: string, onClose: () => void}> = ({ question, onClose }) => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isHistoryLoading, setIsHistoryLoading] = useState(true);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const loadChat = async () => {
            setIsHistoryLoading(true);
            const history = await getChatHistory('tutor');
            if(history && history.length > 0) {
                setMessages(history);
            } else {
                const initialMsg: ChatMessage = { sender: 'ai', text: "Hello! I'm your AI Tutor. How can I help you understand this question better?" };
                setMessages([initialMsg]);
            }
            setIsHistoryLoading(false);
        }
        loadChat();
    }, []);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!userInput.trim() || isLoading) return;

        const userMessage: ChatMessage = { sender: 'user', text: userInput };
        const newMessages: ChatMessage[] = [...messages, userMessage, { sender: 'ai', text: '' }];
        setMessages(newMessages);
        const currentUserInput = userInput;
        setUserInput('');
        setIsLoading(true);

        try {
            await saveChatMessage('tutor', userMessage);
            const messageToSend = `The user is asking for help with the following question: "${question}". Their message is: "${currentUserInput}"`;
            
            let fullAiResponse = '';
            const stream = getSkillTutorResponseStream(messageToSend);

            for await (const chunk of stream) {
                fullAiResponse += chunk;
                setMessages(prev => {
                    const updatedMessages = [...prev];
                    const lastMessage = updatedMessages[updatedMessages.length - 1];
                    if (lastMessage && lastMessage.sender === 'ai') {
                        lastMessage.text = fullAiResponse;
                    }
                    return updatedMessages;
                });
            }

            if (fullAiResponse) {
                await saveChatMessage('tutor', { sender: 'ai', text: fullAiResponse });
            }
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred.';
            const errorMsg: ChatMessage = { sender: 'ai', text: `Sorry, I encountered an error: ${errorMessage}` };
             setMessages(prev => {
                const updatedMessages = [...prev];
                const lastMessage = updatedMessages[updatedMessages.length - 1];
                if (lastMessage && lastMessage.sender === 'ai' && lastMessage.text === '') {
                    updatedMessages[updatedMessages.length - 1] = errorMsg;
                    return updatedMessages;
                }
                return [...prev, errorMsg];
            });
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-lg flex flex-col h-[70vh]">
                 <div className="flex justify-between items-center mb-4">
                     <h2 className="text-lg font-bold text-white flex items-center"><QuestionMarkCircleIcon className="text-brand-purple mr-2"/> AI Tutor</h2>
                     <button onClick={onClose} className="p-1 rounded-full hover:bg-dark-purple-card-border"><XMarkIcon /></button>
                 </div>
                 <div className="flex-1 overflow-y-auto pr-2 -mr-2 space-y-4 mb-4">
                    {isHistoryLoading ? (
                        <div className="flex justify-center items-center h-full"><Loader /></div>
                    ) : (
                      <>
                        {messages.map((msg, index) => (
                            <div key={index} className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                                {msg.sender === 'ai' && (
                                    <div className="w-8 h-8 rounded-full bg-brand-purple flex items-center justify-center flex-shrink-0">
                                        <SparklesIcon className="w-5 h-5 text-dark-purple-bg" />
                                    </div>
                                )}
                                <div className={`p-3 rounded-lg max-w-sm ${msg.sender === 'ai' ? 'bg-dark-purple-card-border text-light-purple-text' : 'bg-brand-purple text-dark-purple-bg'}`}>
                                    {msg.text ? (
                                        <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                                    ) : (
                                        <div className="flex items-center justify-center space-x-1">
                                            <span className="w-2 h-2 bg-light-purple-text-muted rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                            <span className="w-2 h-2 bg-light-purple-text-muted rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                            <span className="w-2 h-2 bg-light-purple-text-muted rounded-full animate-bounce"></span>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                        <div ref={messagesEndRef} />
                      </>
                    )}
                 </div>
                 <form onSubmit={handleSubmit}>
                    <div className="relative">
                        <input
                            type="text"
                            value={userInput}
                            onChange={(e) => setUserInput(e.target.value)}
                            placeholder="Ask for a hint or explanation..."
                            className="w-full p-3 pr-20 bg-dark-purple-bg border border-dark-purple-card-border text-light-purple-text rounded-lg focus:ring-brand-purple focus:border-brand-purple"
                            disabled={isLoading || isHistoryLoading}
                        />
                        <Button type="submit" size="sm" className="absolute right-2.5 top-1/2 -translate-y-1/2" disabled={isLoading || !userInput.trim()}>
                            Send
                        </Button>
                    </div>
                </form>
            </Card>
        </div>
    );
};

export default SkillDiagnostic;