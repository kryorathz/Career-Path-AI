import React from 'react';
import { ResponsiveContainer, RadialBarChart, RadialBar, PolarAngleAxis, Cell } from 'recharts';
import Card from './ui/Card';
import Button from './ui/Button';
import { ArrowRightIcon, BookOpenIcon, PencilSquareIcon, DocumentIcon, GlobeAltIcon, LightBulbIcon, BriefcaseIcon, CodeBracketIcon, ChatBubbleIcon } from './icons/Icons';
import { useAppContext } from '../App';
import type { ImprovementPlan } from '../types';


const ProfileScoreChart: React.FC<{score: number}> = ({score}) => (
    <div className="w-full h-64 relative">
        <ResponsiveContainer width="100%" height="100%">
            <RadialBarChart 
                innerRadius="70%" 
                outerRadius="100%" 
                data={[{name: 'score', value: score}]} 
                startAngle={90} 
                endAngle={-270}
                barSize={30}
            >
                <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
                <RadialBar background={{ fill: '#441E4B' }} dataKey="value" cornerRadius={15}>
                   <Cell fill="#A78BFA" />
                </RadialBar>
            </RadialBarChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
             <span className="text-5xl font-bold text-white">{score}</span>
             <span className="text-sm text-light-purple-text-muted mt-1">Competency Score</span>
        </div>
    </div>
);

const ImprovementPlanCard: React.FC<{plan: ImprovementPlan}> = ({plan}) => {
    const { setActivePage, setCoachContext } = useAppContext();
    const icons = {
        Project: <CodeBracketIcon className="w-6 h-6 text-brand-purple" />,
        Internship: <BriefcaseIcon className="w-6 h-6 text-brand-purple" />,
        Course: <BookOpenIcon className="w-6 h-6 text-brand-purple" />
    }
    
    const handleDiscuss = () => {
        setCoachContext("Let's discuss my resume improvement plan.");
        setActivePage('interview-prep');
    }

    return (
        <Card className="lg:col-span-3">
            <div className="flex items-center mb-4">
                <LightBulbIcon className="w-6 h-6 text-brand-purple mr-3"/>
                <h2 className="text-xl font-semibold text-white">Your Resume Improvement Plan</h2>
            </div>
            <p className="text-sm text-light-purple-text-muted mb-6">Here are a few AI-powered suggestions to make your resume stand out to recruiters.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                {plan.suggestions.slice(0, 3).map((item, index) => (
                    <div key={index} className="bg-dark-purple-bg p-4 rounded-lg border border-dark-purple-card-border">
                        <div className="flex items-center mb-2">
                           <div className="p-2 bg-brand-purple-light rounded-full mr-3">
                              {icons[item.type]}
                           </div>
                           <div>
                             <p className="font-semibold text-white">{item.title}</p>
                             <p className="text-xs font-medium text-brand-purple">{item.type}</p>
                           </div>
                        </div>
                        <p className="text-sm text-light-purple-text-muted">{item.description}</p>
                    </div>
                ))}
            </div>
             <div className="text-center">
                 <Button onClick={handleDiscuss}>
                    Discuss with AI Coach <ChatBubbleIcon className="ml-2 w-4 h-4"/>
                 </Button>
            </div>
        </Card>
    )
}


const Dashboard: React.FC = () => {
    const { analysis, improvementPlan, setActivePage } = useAppContext();

    if (!analysis) {
        return (
            <div className="flex items-center justify-center h-full">
                <Card className="max-w-2xl text-center">
                    <DocumentIcon className="mx-auto h-12 w-12 text-light-purple-text-muted" />
                    <h1 className="mt-4 text-2xl font-bold text-white">Welcome to CareerPathAI</h1>
                    <p className="mt-2 text-light-purple-text-muted">Get started by analyzing your resume to unlock your personalized career dashboard, tailored recommendations, and more.</p>
                    <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-4">
                        <Button onClick={() => setActivePage('resume-analyzer')} size="lg">
                            Analyze My Resume
                        </Button>
                        <Button onClick={() => setActivePage('career-hub')} size="lg" variant="secondary">
                            Explore Career Opportunities <GlobeAltIcon className="ml-2 w-5 h-5"/>
                        </Button>
                    </div>
                </Card>
            </div>
        )
    }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-white">Welcome back, {analysis.name.split(' ')[0]} 👋</h1>
        <p className="mt-1 text-light-purple-text-muted">Here's your career progress summary based on your resume.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {improvementPlan && <ImprovementPlanCard plan={improvementPlan} />}

        {/* Left Column */}
        <div className="lg:col-span-2 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <Card>
                    <div className="flex items-center justify-between">
                         <h2 className="text-lg font-semibold text-white">Resume Builder</h2>
                         <PencilSquareIcon className="w-6 h-6 text-brand-purple"/>
                    </div>
                    <p className="text-sm text-light-purple-text-muted mt-1">Your resume data has been imported. Edit and enhance it now.</p>
                    <Button onClick={() => setActivePage('resume-builder')} variant="secondary" className="mt-4 w-full">Open Builder</Button>
                </Card>
                 <Card>
                    <div className="flex items-center justify-between">
                        <h2 className="text-lg font-semibold text-white">AI Career Coach</h2>
                        <ChatBubbleIcon className="w-6 h-6 text-brand-purple"/>
                    </div>
                    <p className="text-sm text-light-purple-text-muted mt-1">Practice mock interviews based on your profile.</p>
                    <Button onClick={() => setActivePage('interview-prep')} variant="secondary" className="mt-4 w-full">Start Chatting</Button>
                </Card>
            </div>

            <Card>
                <h2 className="text-lg font-semibold text-white">Skill Analysis</h2>
                <p className="text-sm text-light-purple-text-muted mt-1">These skills were extracted from your resume. Test your knowledge!</p>
                <div className="mt-4 flex flex-wrap gap-2">
                    {analysis.skills.slice(0, 10).map(skill => (
                        <span key={skill} className="px-3 py-1 text-sm font-medium text-brand-purple bg-brand-purple-light rounded-full">{skill}</span>
                    ))}
                </div>
                 <Button onClick={() => setActivePage('skill-diagnostic')} variant="secondary" className="mt-4">
                    Go to Skill Diagnostic <ArrowRightIcon className="ml-2 w-4 h-4" />
                </Button>
            </Card>

        </div>

        {/* Right Column */}
        <div className="space-y-8">
            <Card>
                <h2 className="text-lg font-semibold text-white mb-2">Profile Score</h2>
                {/* Assuming a score is generated or can be derived */}
                <ProfileScoreChart score={analysis.feedback?.length ? (analysis.feedback.length * 13) % 40 + 60 : 78} />
            </Card>

            <Card>
                <h2 className="text-lg font-semibold text-white">Career Hub</h2>
                <p className="text-sm text-light-purple-text-muted mt-1">Find personalized courses and jobs to bridge your skill gaps.</p>
                 <Button onClick={() => setActivePage('career-hub')} className="mt-4 w-full">
                    Explore Opportunities
                </Button>
            </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;