
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="flex-shrink-0 bg-dark-purple-sidebar border-b border-dark-purple-card-border no-print">
      <div className="flex items-center justify-between p-4 h-20">
        {/* Header content removed for a cleaner UI */}
      </div>
    </header>
  );
};

export default Header;