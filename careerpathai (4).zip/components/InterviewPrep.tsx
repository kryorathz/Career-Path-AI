import React, { useState, useRef, useEffect } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import Loader from './ui/Loader';
import { getAICoachResponseStream } from '../services/geminiService';
import { saveChatMessage, getChatHistory } from '../services/databaseService';
import type { ChatMessage } from '../types';
import { SparklesIcon } from './icons/Icons';
import { useAppContext } from '../App';

const InterviewPrep: React.FC = () => {
    const { analysis, setActivePage, coachContext, setCoachContext } = useAppContext();
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isHistoryLoading, setIsHistoryLoading] = useState(true);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Initialize chat and load history
    useEffect(() => {
        const loadChat = async () => {
            setIsHistoryLoading(true);
            const history = await getChatHistory('coach');
            if (history && history.length > 0) {
                setMessages(history);
            } else {
                const initialMsg: ChatMessage = { sender: 'ai', text: "Hello! I'm your AI Career Coach. How can I help you today? You can ask for career advice or we can start a mock interview." };
                setMessages([initialMsg]);
            }
            setIsHistoryLoading(false);
        };
        loadChat();
    }, []);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);
    
    // Handle incoming context from other pages (e.g., Dashboard)
    useEffect(() => {
        if (coachContext && !isHistoryLoading) {
            const contextMessage: ChatMessage = {
                sender: 'ai',
                text: `I see you're here to discuss your resume improvement plan. That's a great step! I've reviewed the suggestions. Where would you like to start? We can talk about projects, finding internships, or recommended courses.`
            };
            setMessages(prev => [...prev, contextMessage]);
            saveChatMessage('coach', contextMessage);
            setCoachContext(null); // Clear context after use
        }
    }, [coachContext, setCoachContext, isHistoryLoading]);

    if (!analysis) {
        return (
            <Card className="text-center">
                <h2 className="text-xl font-bold text-white">Analyze Your Resume First</h2>
                <p className="mt-2 text-light-purple-text-muted">Upload your resume so the AI Coach can provide you with a personalized mock interview experience.</p>
                <Button onClick={() => setActivePage('resume-analyzer')} className="mt-4">Go to Analyzer</Button>
            </Card>
        );
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!userInput.trim() || isLoading) return;

        const userMessage: ChatMessage = { sender: 'user', text: userInput };
        const newMessages: ChatMessage[] = [...messages, userMessage, { sender: 'ai', text: '' }];
        setMessages(newMessages);
        const currentUserInput = userInput;
        setUserInput('');
        setIsLoading(true);

        try {
            await saveChatMessage('coach', userMessage);

            let messageToSend = currentUserInput;
            if (messages.length <= 3 && analysis?.summary) {
                messageToSend = `(My resume summary for your context: "${analysis.summary}"). Now, here is my prompt: ${currentUserInput}`;
            }

            let fullAiResponse = '';
            const stream = getAICoachResponseStream(messageToSend);
            
            for await (const chunk of stream) {
                fullAiResponse += chunk;
                setMessages(prev => {
                    const updatedMessages = [...prev];
                    const lastMessage = updatedMessages[updatedMessages.length - 1];
                    if (lastMessage && lastMessage.sender === 'ai') {
                        lastMessage.text = fullAiResponse;
                    }
                    return updatedMessages;
                });
            }
            
            if (fullAiResponse) {
                await saveChatMessage('coach', { sender: 'ai', text: fullAiResponse });
            }

        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred.';
            const errorMsg: ChatMessage = { sender: 'ai', text: `Sorry, I encountered an error: ${errorMessage}` };
            setMessages(prev => {
                const updatedMessages = [...prev];
                const lastMessage = updatedMessages[updatedMessages.length - 1];
                if (lastMessage && lastMessage.sender === 'ai' && lastMessage.text === '') {
                    updatedMessages[updatedMessages.length - 1] = errorMsg;
                    return updatedMessages;
                }
                return [...prev, errorMsg];
            });
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-3xl mx-auto">
            <h1 className="text-3xl font-bold text-center text-white">AI Career Coach</h1>
            <p className="mt-1 text-center text-light-purple-text-muted">Practice interviews and get instant feedback from your AI assistant.</p>
            
            <Card className="mt-8">
                <div className="h-[60vh] flex flex-col">
                    <div className="flex-1 overflow-y-auto pr-4 -mr-4 space-y-4">
                        {isHistoryLoading ? (
                           <div className="flex justify-center items-center h-full">
                             <Loader />
                           </div>
                        ) : (
                          <>
                            {messages.map((msg, index) => (
                                <div key={index} className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                                    {msg.sender === 'ai' && (
                                        <div className="w-8 h-8 rounded-full bg-brand-purple flex items-center justify-center flex-shrink-0">
                                            <SparklesIcon className="w-5 h-5 text-dark-purple-bg" />
                                        </div>
                                    )}
                                    <div className={`p-3 rounded-lg max-w-lg ${msg.sender === 'ai' ? 'bg-dark-purple-card-border text-light-purple-text' : 'bg-brand-purple text-dark-purple-bg'}`}>
                                        {msg.text ? (
                                            <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                                        ) : (
                                            <div className="flex items-center justify-center space-x-1">
                                               <span className="w-2 h-2 bg-light-purple-text-muted rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                               <span className="w-2 h-2 bg-light-purple-text-muted rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                               <span className="w-2 h-2 bg-light-purple-text-muted rounded-full animate-bounce"></span>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ))}
                            <div ref={messagesEndRef} />
                          </>
                        )}
                    </div>
                    <form onSubmit={handleSubmit} className="mt-6">
                        <div className="relative">
                            <textarea
                                value={userInput}
                                onChange={(e) => setUserInput(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter' && !e.shiftKey) {
                                        handleSubmit(e);
                                    }
                                }}
                                placeholder="Ask a question or start a mock interview..."
                                className="w-full p-3 pr-24 bg-dark-purple-bg border border-dark-purple-card-border text-light-purple-text rounded-lg focus:ring-brand-purple focus:border-brand-purple resize-none"
                                rows={2}
                                disabled={isLoading || isHistoryLoading}
                            />
                            <Button type="submit" className="absolute right-3 bottom-2.5" disabled={isLoading || !userInput.trim()}>
                                Send
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default InterviewPrep;