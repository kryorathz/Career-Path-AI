
import React, { useState, useEffect } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import Loader from './ui/Loader';
import type { ResumeAnalysis, ResumeEvaluation } from '../types';
import { SparklesIcon, TrashIcon, PlusIcon, ExclamationTriangleIcon, ArrowRightIcon, BriefcaseIcon, AcademicCapIcon, CodeBracketIcon, LightBulbIcon, CheckCircleIcon } from './icons/Icons';
import { evaluateResumeContent, improveResumePoint } from '../services/geminiService';
import { updateResumeData } from '../services/databaseService';
import { useAppContext } from '../App';

type EditableResume = Omit<ResumeAnalysis, 'feedback'>;
type SectionKey = 'experience' | 'education' | 'projects';
type PopoverState = { section: SectionKey, index: number } | null;
type Template = 'classic' | 'modern';

const ResumeBuilder: React.FC = () => {
    const { analysis, setActivePage, setAnalysis } = useAppContext();
    const [resume, setResume] = useState<EditableResume | null>(null);
    const [initialResume, setInitialResume] = useState<EditableResume | null>(null);
    const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
    const [evaluation, setEvaluation] = useState<ResumeEvaluation | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [isImproving, setIsImproving] = useState<PopoverState>(null);
    const [suggestions, setSuggestions] = useState<string[]>([]);
    const [activePopover, setActivePopover] = useState<PopoverState>(null);
    const [error, setError] = useState<string | null>(null);
    const [template, setTemplate] = useState<Template>('classic');

    useEffect(() => {
        if (analysis) {
            const { feedback, ...editableData } = analysis;
            setResume(editableData);
            setInitialResume(editableData);
        }
    }, [analysis]);
    
    if (!analysis || !resume) {
        return (
            <Card className="text-center">
                <h2 className="text-xl font-bold text-white">Analyze Your Resume First</h2>
                <p className="mt-2 text-light-purple-text-muted">Upload your resume to automatically build and edit it here.</p>
                <Button onClick={() => setActivePage('resume-analyzer')} className="mt-4">Go to Analyzer</Button>
            </Card>
        );
    }

    const handleChange = (section: keyof EditableResume | 'contact', index: number | null, field: string, value: string) => {
        setResume(prev => {
            if (!prev) return null;
            
            // Use a deep copy to ensure a new object reference is created, forcing a re-render.
            const newResume = JSON.parse(JSON.stringify(prev));
    
            if (section === 'contact') {
                // Handles name, email, phone
                newResume[field] = value;
            } else if (section === 'summary' && index === null) {
                // Handles summary
                newResume[section] = value;
            } else if (index !== null && Array.isArray(newResume[section])) {
                // Handles experience, education, projects arrays
                const list = newResume[section];
                if (list && list[index]) {
                    list[index][field] = value;
                }
            }
            
            return newResume;
        });
    };
    
    const handleSkillChange = (index: number, value: string) => {
        setResume(prev => {
            if (!prev) return null;
            const newSkills = [...(prev.skills || [])];
            newSkills[index] = value;
            return { ...prev, skills: newSkills };
        });
    };

    const addListItem = (section: 'experience' | 'education' | 'projects' | 'skills') => {
        setResume(prev => {
            if (!prev) return null;
            const newList = [...(prev[section] || [])];
            if (section === 'experience') newList.push({ role: '', company: '', duration: '', description: '' });
            if (section === 'education') newList.push({ degree: '', institution: '', year: '' });
            if (section === 'projects') newList.push({ name: '', description: '' });
            if (section === 'skills') newList.push('');
            // @ts-ignore
            return { ...prev, [section]: newList };
        });
    };

    const removeListItem = (section: keyof EditableResume, index: number) => {
        setResume(prev => {
            if (!prev) return null;
            return {
                ...prev,
                // @ts-ignore
                [section]: prev[section].filter((_: any, i: number) => i !== index),
            }
        });
    };
    
    const handleEvaluate = async () => {
        setIsLoading(true);
        setError(null);
        setEvaluation(null);
        try {
            const result = await evaluateResumeContent(resume);
            setEvaluation(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }

    const handleImproveDescription = async (section: SectionKey, index: number, text: string) => {
        if (!text) return;
        setIsImproving({ section, index });
        setError(null);
        setSuggestions([]);
        try {
            const result = await improveResumePoint(text);
            setSuggestions(result.suggestions);
            setActivePopover({ section, index });
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsImproving(null);
        }
    }
    
    const handleSave = async () => {
        if (!resume) return;
        setSaveStatus('saving');
        setError(null);
        try {
            // Reconstruct the full ResumeAnalysis object to pass to the service and context
            const updatedAnalysis: ResumeAnalysis = {
                ...resume,
                feedback: analysis?.feedback, // Keep original feedback
            };
            await updateResumeData(updatedAnalysis); // This is now a no-op
            setAnalysis(updatedAnalysis); // Update global context
            setInitialResume(resume); // Update initial state to reflect saved changes
            setSaveStatus('saved');
            setTimeout(() => setSaveStatus('idle'), 2000); // Reset after 2 seconds
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
            setSaveStatus('idle');
        }
    };

    const handlePrint = () => {
        window.print();
    }
    
    const hasChanges = JSON.stringify(initialResume) !== JSON.stringify(resume);

    const getSaveButtonContent = () => {
        switch(saveStatus) {
            case 'saving':
                return <><Loader /> Saving...</>;
            case 'saved':
                return <><CheckCircleIcon /> Saved!</>;
            case 'idle':
            default:
                return 'Save Changes';
        }
    };

    const inputClasses = "w-full p-2 bg-dark-purple-sidebar border border-dark-purple-card-border rounded mt-1 text-light-purple-text focus:ring-brand-purple focus:border-brand-purple";

    return (
        <div className="relative">
             <div 
                className="absolute inset-0 -z-10 h-full w-full bg-transparent" 
                style={{backgroundImage: 'radial-gradient(rgba(167, 139, 250, 0.1) 1px, transparent 1px)', backgroundSize: '16px 16px'}}
             ></div>

            <div className="flex justify-between items-center no-print">
                <div>
                    <h1 className="text-3xl font-bold text-white">Resume Builder</h1>
                    <p className="mt-1 text-light-purple-text-muted">Your resume has been loaded. Refine the content and evaluate it with AI.</p>
                </div>
                <div className="flex gap-4">
                     <Button onClick={handleSave} disabled={!hasChanges || saveStatus === 'saving'}>
                        {getSaveButtonContent()}
                     </Button>
                     <Button onClick={handleEvaluate} disabled={isLoading || saveStatus === 'saving'}>
                        {isLoading ? <><Loader /> Evaluating...</> : <><SparklesIcon className="mr-2"/> Evaluate with AI</>}
                     </Button>
                     <Button onClick={handlePrint} variant="secondary">Download PDF</Button>
                </div>
            </div>

            {error && (
                <Card className="mt-6 bg-red-900/50 border-red-500/50 no-print">
                    <div className="flex items-center">
                        <ExclamationTriangleIcon className="text-red-400"/>
                        <p className="ml-2 text-sm font-medium text-red-300">{error}</p>
                    </div>
                </Card>
             )}

            {evaluation && (
                 <Card className="mt-8 no-print">
                    <h2 className="text-xl font-semibold flex items-center mb-4 text-white"><SparklesIcon className="mr-2 text-brand-purple w-6 h-6"/> AI Evaluation Result</h2>
                    <div className="flex flex-col md:flex-row items-center gap-8 bg-dark-purple-bg p-6 rounded-lg">
                        <EvaluationScoreCircle score={evaluation.score} />
                        <div className="flex-1">
                            <h3 className="font-semibold text-white text-lg">Suggestions for Improvement:</h3>
                            <ul className="list-disc list-inside mt-2 text-sm text-light-purple-text space-y-2">
                                {evaluation.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                            </ul>
                        </div>
                    </div>
                 </Card>
            )}
            
            {evaluation && evaluation.score < 75 && (
                <Card className="mt-8 no-print bg-dark-purple-card border-brand-purple/50">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center">
                           <div className="p-3 bg-brand-purple-light rounded-full mr-4">
                             <LightBulbIcon className="w-6 h-6 text-brand-purple"/>
                           </div>
                           <div>
                                <h2 className="text-xl font-semibold text-white">Boost Your Resume Score</h2>
                                <p className="mt-1 text-light-purple-text-muted">Your score is a great start! Let's find opportunities to make your resume even stronger.</p>
                           </div>
                        </div>
                        <Button onClick={() => setActivePage('career-hub')}>
                           Find Courses & Internships <ArrowRightIcon className="ml-2"/>
                        </Button>
                    </div>
                </Card>
            )}


             <div className="my-8 flex justify-center gap-4 no-print">
                <Button variant={template === 'classic' ? 'primary' : 'secondary'} onClick={() => setTemplate('classic')}>Classic Template</Button>
                <Button variant={template === 'modern' ? 'primary' : 'secondary'} onClick={() => setTemplate('modern')}>Modern Template</Button>
            </div>


            <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                {/* Editor Column */}
                <div className="space-y-6 no-print">
                    <EditorCard title="Contact Information">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="text-sm font-medium text-light-purple-text-muted">Full Name</label>
                                <input type="text" className={inputClasses} value={resume.name} onChange={e => handleChange('contact', null, 'name', e.target.value)} />
                            </div>
                            <div>
                                <label className="text-sm font-medium text-light-purple-text-muted">Email</label>
                                <input type="email" className={inputClasses} value={resume.email} onChange={e => handleChange('contact', null, 'email', e.target.value)} />
                            </div>
                            <div className="md:col-span-2">
                                <label className="text-sm font-medium text-light-purple-text-muted">Phone</label>
                                <input type="tel" className={inputClasses} value={resume.phone} onChange={e => handleChange('contact', null, 'phone', e.target.value)} />
                            </div>
                        </div>
                    </EditorCard>

                    <EditorCard title="Professional Summary">
                        <textarea rows={4} className={inputClasses} value={resume.summary} onChange={e => handleChange('summary', null, 'summary', e.target.value)} />
                    </EditorCard>

                    <EditorCard title="Skills">
                        <div className="grid grid-cols-2 gap-2">
                         {(resume.skills || []).map((skill, i) => (
                           <div key={i} className="flex items-center">
                              <input type="text" className={inputClasses} value={skill} onChange={e => handleSkillChange(i, e.target.value)} />
                              <button onClick={() => removeListItem('skills', i)} className="p-2 text-light-purple-text-muted hover:text-red-500 hover:bg-red-500/10 rounded-full ml-1 mt-1 transition-colors"><TrashIcon className="w-4 h-4"/></button>
                           </div>
                         ))}
                        </div>
                        <Button onClick={() => addListItem('skills')} variant="secondary" className="mt-2 w-full"><PlusIcon className="mr-2 w-4 h-4" /> Add Skill</Button>
                    </EditorCard>
                    
                    <EditorSection icon={<BriefcaseIcon />} title="Experience" items={resume.experience || []} sectionKey="experience" onChange={handleChange} onAdd={() => addListItem('experience')} onRemove={removeListItem} onImprove={handleImproveDescription} activePopover={activePopover} setActivePopover={setActivePopover} suggestions={suggestions} isImproving={isImproving} inputClasses={inputClasses} />
                    <EditorSection icon={<AcademicCapIcon />} title="Education" items={resume.education || []} sectionKey="education" onChange={handleChange as any} onAdd={() => addListItem('education')} onRemove={removeListItem} inputClasses={inputClasses} />
                    <EditorSection icon={<CodeBracketIcon />} title="Projects" items={resume.projects || []} sectionKey="projects" onChange={handleChange as any} onAdd={() => addListItem('projects')} onRemove={removeListItem} onImprove={handleImproveDescription} activePopover={activePopover} setActivePopover={setActivePopover} suggestions={suggestions} isImproving={isImproving} inputClasses={inputClasses}/>
                </div>

                {/* Preview Column */}
                <div className={`bg-white text-slate-800 rounded-lg shadow-2xl shadow-brand-purple/10 ${template === 'classic' ? 'font-serif' : 'font-sans'}`}>
                  <div id="resume-preview" className="p-8 lg:p-10">
                      <div className={template === 'modern' ? 'bg-slate-800 text-white p-6 -m-10 mb-6 rounded-t-lg' : 'text-center'}>
                          <h1 className="text-3xl font-bold">{resume.name}</h1>
                          <p className={`text-sm mt-1 ${template === 'modern' ? 'text-slate-300' : 'text-slate-600'}`}>{resume.email} | {resume.phone}</p>
                      </div>
                      
                      <ResumePreviewSection title="Summary" template={template}>
                          <p className="text-sm">{resume.summary}</p>
                      </ResumePreviewSection>

                      <ResumePreviewSection title="Skills" template={template}>
                          <div className="flex flex-wrap gap-2">
                             {(resume.skills || []).filter(s => s.trim() !== '').map(skill => <span key={skill} className={`px-3 py-1 text-xs font-medium rounded-full ${template === 'modern' ? 'bg-slate-200 text-slate-700' : 'bg-purple-100 text-purple-800'}`}>{skill}</span>)}
                          </div>
                      </ResumePreviewSection>

                      <ResumePreviewSection title="Experience" template={template}>
                          {(resume.experience || []).map((exp, i) => exp.role && (
                            <div key={i} className="mb-3 [break-inside:avoid]">
                                <div className="flex justify-between items-baseline">
                                   <h3 className="font-semibold">{exp.role} - {exp.company}</h3>
                                   <p className="text-xs text-slate-500">{exp.duration}</p>
                                </div>
                                <p className="text-sm mt-1 whitespace-pre-wrap">{exp.description}</p>
                            </div>
                          ))}
                      </ResumePreviewSection>

                      <ResumePreviewSection title="Education" template={template}>
                          {(resume.education || []).map((edu, i) => edu.degree && (
                            <div key={i} className="mb-2 [break-inside:avoid]">
                                <div className="flex justify-between items-baseline">
                                   <h3 className="font-semibold">{edu.degree}</h3>
                                   <p className="text-xs text-slate-500">{edu.year}</p>
                                </div>
                                <p className="text-sm">{edu.institution}</p>
                            </div>
                          ))}
                      </ResumePreviewSection>

                      <ResumePreviewSection title="Projects" template={template}>
                          {(resume.projects || []).map((proj, i) => proj.name && (
                            <div key={i} className="mb-2 [break-inside:avoid]">
                                <h3 className="font-semibold">{proj.name}</h3>
                                <p className="text-sm mt-1 whitespace-pre-wrap">{proj.description}</p>
                            </div>
                          ))}
                      </ResumePreviewSection>
                  </div>
                </div>
            </div>
        </div>
    );
};

// --- Sub-components for Builder ---
const EvaluationScoreCircle: React.FC<{ score: number }> = ({ score }) => {
    const radius = 54;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (score / 100) * circumference;

    return (
        <div className="relative w-36 h-36 flex-shrink-0">
            <svg className="w-full h-full" viewBox="0 0 120 120">
                <circle className="stroke-dark-purple-card-border" strokeWidth="12" fill="none" cx="60" cy="60" r={radius} />
                <circle
                    className="stroke-brand-purple"
                    strokeWidth="12"
                    strokeLinecap="round"
                    fill="none"
                    cx="60"
                    cy="60"
                    r={radius}
                    transform="rotate(-90 60 60)"
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    style={{ transition: 'stroke-dashoffset 0.8s ease-out' }}
                />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-bold text-white">{score}</span>
                <span className="text-xs text-light-purple-text-muted font-semibold tracking-wider">ATS SCORE</span>
            </div>
        </div>
    );
};

const EditorCard: React.FC<{title: string, children: React.ReactNode, icon?: React.ReactElement<{ className?: string }>}> = ({title, children, icon}) => (
    <Card>
        <h2 className="text-lg font-semibold mb-3 text-white flex items-center">
            {icon && React.cloneElement(icon, { className: "w-5 h-5 mr-2 text-brand-purple" })}
            {title}
        </h2>
        {children}
    </Card>
);

const ResumePreviewSection: React.FC<{title: string, children: React.ReactNode, template: Template}> = ({title, children, template}) => (
    <div className="mt-4">
        <h2 className={`text-sm font-bold uppercase pb-1 mb-2 ${template === 'modern' ? 'text-slate-600 border-b-2 border-slate-300' : 'text-purple-700 border-b-2 border-purple-200'}`}>{title}</h2>
        {children}
    </div>
);


const EditorSection = ({ title, icon, items, sectionKey, onChange, onAdd, onRemove, onImprove, activePopover, setActivePopover, suggestions, isImproving, inputClasses }: {
    title: string,
    icon: React.ReactElement<{ className?: string }>,
    items: any[],
    sectionKey: SectionKey,
    onChange: (section: SectionKey, index: number, field: string, value: string) => void,
    onAdd: () => void,
    onRemove: (section: SectionKey, index: number) => void,
    onImprove?: (section: SectionKey, index: number, text: string) => void,
    activePopover?: PopoverState,
    setActivePopover?: (state: PopoverState) => void,
    suggestions?: string[],
    isImproving?: PopoverState,
    inputClasses: string
}) => {
    const fields = Object.keys(items[0] || {});
    return (
        <EditorCard title={title} icon={icon}>
            <div className="space-y-4">
            {items.map((item, index) => (
                <div key={index} className="p-4 border border-dark-purple-card-border rounded-lg bg-dark-purple-bg relative">
                    <button onClick={() => onRemove(sectionKey, index)} className="absolute top-2 right-2 p-1 text-light-purple-text-muted hover:text-red-500 hover:bg-red-500/10 rounded-full transition-colors"><TrashIcon className="w-4 h-4" /></button>
                    {fields.map(field => (
                        <div key={field} className="mb-2">
                            <label className="text-sm font-medium capitalize text-light-purple-text-muted">{field.replace(/([A-Z])/g, ' $1')}</label>
                            {field === 'description' ? (
                                <div className="relative">
                                    <textarea rows={3} className={inputClasses} value={item[field]} onChange={e => onChange(sectionKey, index, field, e.target.value)} />
                                    {onImprove && (
                                        <Button
                                            variant="secondary"
                                            size="sm"
                                            className="absolute bottom-2 right-2"
                                            onClick={() => onImprove(sectionKey, index, item[field])}
                                            disabled={isImproving?.section === sectionKey && isImproving?.index === index}
                                        >
                                            {isImproving?.section === sectionKey && isImproving?.index === index ? <><Loader size="sm" /> Gen...</> : <><SparklesIcon className="w-4 h-4 mr-1"/> Improve</>}
                                        </Button>
                                    )}
                                    {activePopover?.section === sectionKey && activePopover?.index === index && suggestions && suggestions.length > 0 && (
                                        <div className="absolute z-10 w-full mt-1 bg-dark-purple-card border border-dark-purple-card-border rounded-lg shadow-lg">
                                            <ul className="py-1">
                                                {suggestions.map((suggestion, i) => (
                                                    <li key={i} className="px-3 py-2 text-sm text-light-purple-text hover:bg-brand-purple-light cursor-pointer" onClick={() => {
                                                        onChange(sectionKey, index, 'description', suggestion);
                                                        setActivePopover?.(null);
                                                    }}>
                                                        {suggestion}
                                                    </li>
                                                ))}
                                            </ul>
                                             <button onClick={() => setActivePopover?.(null)} className="w-full text-center text-xs py-1 bg-dark-purple-bg hover:bg-dark-purple-sidebar border-t border-dark-purple-card-border">Close</button>
                                        </div>
                                    )}
                                </div>
                            ) : (
                                <input type="text" className={inputClasses} value={item[field]} onChange={e => onChange(sectionKey, index, field, e.target.value)} />
                            )}
                        </div>
                    ))}
                </div>
            ))}
            </div>
            <Button onClick={onAdd} variant="secondary" className="mt-4 w-full"><PlusIcon className="mr-2 w-4 h-4"/> Add {title.slice(0, -1)}</Button>
        </EditorCard>
    );
}


export default ResumeBuilder;
