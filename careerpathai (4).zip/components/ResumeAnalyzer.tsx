
import React, { useState } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import Loader from './ui/Loader';
import { analyzeResume, generateImprovementPlan } from '../services/geminiService';
import { saveResumeAnalysis } from '../services/databaseService';
import { DocumentPlusIcon, CheckCircleIcon, ExclamationTriangleIcon } from './icons/Icons';
import { useAppContext } from '../App';

const ResumeAnalyzer: React.FC = () => {
  const { setAnalysis, setActivePage, setImprovementPlan } = useAppContext();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      setSelectedFile(event.target.files[0]);
      setError(null);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedFile) {
      setError('Please select a file first.');
      return;
    }

    setIsLoading(true);
    setError(null);
    
    try {
      // Step 1: Analyze the resume with the AI
      setLoadingStep('Analyzing resume...');
      const result = await analyzeResume(selectedFile);
      
      // Step 2: Generate the improvement plan
      setLoadingStep('Generating improvement plan...');
      const plan = await generateImprovementPlan(result);
      
      // Step 3: Save the results (this is now a no-op)
      setLoadingStep('Saving your profile...');
      await saveResumeAnalysis(result, plan);

      // Step 4: Update the application's global state
      setAnalysis(result);
      setImprovementPlan(plan);

      // Step 5: Navigate to the personalized dashboard
      setActivePage('dashboard');

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
      setLoadingStep('');
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-white">Resume Analyzer</h1>
        <p className="mt-1 text-light-purple-text-muted">Upload your resume to get AI-powered feedback and populate your profile.</p>
      </div>

      <Card className="mt-8">
        <div className="flex flex-col items-center justify-center w-full">
            <label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full h-64 border-2 border-dark-purple-card-border border-dashed rounded-lg cursor-pointer bg-dark-purple-bg hover:bg-dark-purple-card">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <DocumentPlusIcon className="w-10 h-10 text-light-purple-text-muted" />
                    <p className="mb-2 text-sm text-light-purple-text-muted mt-4"><span className="font-semibold text-brand-purple">Click to upload</span> or drag and drop</p>
                    <p className="text-xs text-light-purple-text-muted">PDF, DOCX (MAX. 5MB)</p>
                </div>
                <input id="dropzone-file" type="file" className="hidden" onChange={handleFileChange} accept=".pdf,.doc,.docx" />
            </label>
            {selectedFile && <p className="mt-4 text-sm text-light-purple-text">Selected file: <span className="font-medium text-white">{selectedFile.name}</span></p>}
        </div>

        <div className="mt-6 flex justify-center">
            <Button onClick={handleAnalyze} disabled={!selectedFile || isLoading}>
                {isLoading ? <><Loader /> {loadingStep}</> : 'Analyze Resume'}
            </Button>
        </div>
      </Card>

      {error && (
        <Card className="mt-6 bg-red-900/50 border-red-500/50">
            <div className="flex items-center">
                <ExclamationTriangleIcon className="text-red-400"/>
                <p className="ml-2 text-sm font-medium text-red-300">{error}</p>
            </div>
        </Card>
      )}

    </div>
  );
};

export default ResumeAnalyzer;
