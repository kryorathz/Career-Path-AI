import React, { useState, createContext, useContext, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import ResumeAnalyzer from './components/ResumeAnalyzer';
import SkillDiagnostic from './components/SkillDiagnostic';
import CareerHub from './components/CareerHub';
import InterviewPrep from './components/InterviewPrep';
import ResumeBuilder from './components/ResumeBuilder';
import Login from './components/auth/Login';
import SignUp from './components/auth/SignUp';
import ForgotPassword from './components/auth/ForgotPassword';
import OtpVerification from './components/auth/OtpVerification';
import { supabase, isSupabaseConfigured } from './services/supabaseClient';
import { getProfileData } from './services/databaseService';
import type { Page, ResumeAnalysis, ImprovementPlan } from './types';
import type { Session, User } from '@supabase/supabase-js';

// --- App Context for Global State ---
interface IAppContext {
  session: Session | null;
  user: User | null;
  analysis: ResumeAnalysis | null;
  setAnalysis: (analysis: ResumeAnalysis | null) => void;
  improvementPlan: ImprovementPlan | null;
  setImprovementPlan: (plan: ImprovementPlan | null) => void;
  activePage: Page;
  setActivePage: (page: Page) => void;
  coachContext: string | null;
  setCoachContext: (context: string | null) => void;
  clearUserData: () => void;
}

const AppContext = createContext<IAppContext | null>(null);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

const AppProvider: React.FC<{ children: React.ReactNode, session: Session, user: User }> = ({ children, session, user }) => {
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);
  const [improvementPlan, setImprovementPlan] = useState<ImprovementPlan | null>(null);
  const [activePage, setActivePage] = useState<Page>('dashboard');
  const [coachContext, setCoachContext] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const clearUserData = () => {
      setAnalysis(null);
      setImprovementPlan(null);
      setActivePage('dashboard');
  }

  useEffect(() => {
    const fetchAndSetProfileData = async () => {
      setIsLoading(true);
      const { analysis: fetchedAnalysis, improvementPlan: fetchedPlan } = await getProfileData();
      setAnalysis(fetchedAnalysis);
      setImprovementPlan(fetchedPlan);
      setIsLoading(false);
    };

    if (session) {
      fetchAndSetProfileData();
    }
  }, [session]);

  return (
    <AppContext.Provider value={{ session, user, analysis, setAnalysis, improvementPlan, setImprovementPlan, activePage, setActivePage, coachContext, setCoachContext, clearUserData }}>
        {isLoading ? <FullScreenLoader /> : children}
    </AppContext.Provider>
  );
};

const FullScreenLoader: React.FC = () => (
    <div className="flex items-center justify-center h-screen bg-dark-purple-bg">
        <svg className="animate-spin h-10 w-10 text-brand-purple" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    </div>
);

// --- Main App Component ---
const App: React.FC = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [authView, setAuthView] = useState<'login' | 'signup' | 'forgotPassword' | 'otp'>('login');
  const [otpEmail, setOtpEmail] = useState('');

  useEffect(() => {
    if (!isSupabaseConfigured || !supabase) {
        // If Supabase isn't configured, we stop the loading screen and drop
        // the user into a non-authenticated state where they can only use the Career Hub.
        setLoading(false);
        return;
    }
    
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);
    });

    // Check for initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
      return <FullScreenLoader />;
  }

  if (!session) {
      switch (authView) {
          case 'signup':
              return <SignUp onNavigateToLogin={() => setAuthView('login')} onSignUpSuccess={(email) => { setOtpEmail(email); setAuthView('otp'); }} />;
          case 'forgotPassword':
              return <ForgotPassword onNavigateToLogin={() => setAuthView('login')} />;
          case 'otp':
              return <OtpVerification email={otpEmail} onNavigateToLogin={() => setAuthView('login')} />;
          case 'login':
          default:
              return <Login onNavigateToSignUp={() => setAuthView('signup')} onNavigateToForgotPassword={() => setAuthView('forgotPassword')} />;
      }
  }

  return (
    <AppProvider session={session} user={user!}>
      <AppContent />
    </AppProvider>
  );
};

const AppContent: React.FC = () => {
  const { activePage } = useAppContext();

  const renderContent = () => {
    switch (activePage) {
      case 'dashboard':
        return <Dashboard />;
      case 'resume-analyzer':
        return <ResumeAnalyzer />;
      case 'skill-diagnostic':
        return <SkillDiagnostic />;
      case 'career-hub':
        return <CareerHub />;
      case 'interview-prep':
        return <InterviewPrep />;
      case 'resume-builder':
        return <ResumeBuilder />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-dark-purple-bg font-sans">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-x-hidden overflow-y-auto p-6 lg:p-8">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default App;
