import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://nwsvlojpgqyrhvpbrmzg.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im53c3Zsb2pwZ3F5cmh2cGJybXpnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTgzMDU1ODIsImV4cCI6MjA3Mzg4MTU4Mn0.PJG_X7jK2LEJUVerVFGhxmeWw5git91mAw5qOtbZaoI';

export const isSupabaseConfigured = !!(supabaseUrl && supabaseAnonKey);

export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;