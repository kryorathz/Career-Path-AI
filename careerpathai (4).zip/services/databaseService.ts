import { supabase, isSupabaseConfigured } from './supabaseClient';
import type { ResumeAnalysis, ImprovementPlan, ChatMessage, SkillQuestion, DiagnosticFeedback } from '../types';

const getCurrentUser = async () => {
    if (!supabase) throw new Error("Supabase is not configured.");
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("User not authenticated.");
    return user;
};

export const getProfileData = async (): Promise<{ analysis: ResumeAnalysis | null, improvementPlan: ImprovementPlan | null }> => {
    if (!isSupabaseConfigured || !supabase) return { analysis: null, improvementPlan: null };
    
    try {
        const user = await getCurrentUser();
        const { data, error } = await supabase
            .from('resume_data')
            .select('analysis, improvement_plan')
            .eq('user_id', user.id)
            .single();

        if (error && error.code !== 'PGRST116') { // PGRST116 = no rows found
            console.error("Error fetching profile data:", error);
            throw error;
        }

        if (data) {
            return {
                analysis: data.analysis as ResumeAnalysis,
                improvementPlan: data.improvement_plan as ImprovementPlan
            };
        }
        return { analysis: null, improvementPlan: null };

    } catch(err) {
        // If user is not authenticated, it's not an app error.
        if(err instanceof Error && err.message === "User not authenticated.") {
            return { analysis: null, improvementPlan: null };
        }
        console.error("Unexpected error in getProfileData:", err);
        return { analysis: null, improvementPlan: null };
    }
};

export const saveResumeAnalysis = async (analysis: ResumeAnalysis, improvementPlan: ImprovementPlan): Promise<void> => {
    if (!isSupabaseConfigured || !supabase) return;
    const user = await getCurrentUser();

    const { error } = await supabase
        .from('resume_data')
        .upsert({
            user_id: user.id,
            analysis: analysis,
            improvement_plan: improvementPlan,
            updated_at: new Date().toISOString()
        }, { onConflict: 'user_id' });

    if (error) {
        console.error("Error saving resume analysis:", error);
        throw new Error(error.message);
    }
};

export const updateResumeData = async (resumeData: ResumeAnalysis): Promise<void> => {
    if (!isSupabaseConfigured || !supabase) return;
    const user = await getCurrentUser();

    const { error } = await supabase
        .from('resume_data')
        .update({
            analysis: resumeData,
            updated_at: new Date().toISOString()
        })
        .eq('user_id', user.id);
    
    if (error) {
        console.error("Error updating resume data:", error);
        throw new Error(error.message);
    }
};

export const getChatHistory = async (chatType: 'coach' | 'hub' | 'tutor'): Promise<ChatMessage[]> => {
    if (!isSupabaseConfigured || !supabase) return [];
    try {
        const user = await getCurrentUser();
        const { data, error } = await supabase
            .from('chat_history')
            .select('message')
            .eq('user_id', user.id)
            .eq('chat_type', chatType)
            .order('created_at', { ascending: true });

        if (error) {
            console.error(`Error fetching ${chatType} chat history:`, error);
            throw error;
        }

        return data ? data.map(row => row.message as ChatMessage) : [];
    } catch (err) {
        if(err instanceof Error && err.message === "User not authenticated.") {
            return [];
        }
        console.error(`Unexpected error fetching ${chatType} chat history:`, err);
        return [];
    }
};

export const saveChatMessage = async (chatType: 'coach' | 'hub' | 'tutor', message: ChatMessage): Promise<void> => {
    if (!isSupabaseConfigured || !supabase) return;
    const user = await getCurrentUser();

    const { error } = await supabase
        .from('chat_history')
        .insert({
            user_id: user.id,
            chat_type: chatType,
            message: message
        });
    
    if (error) {
        console.error(`Error saving ${chatType} chat message:`, error);
        throw new Error(error.message);
    }
};

export const saveSkillDiagnostic = async (
    skill: string, 
    questions: SkillQuestion[], 
    userAnswers: (string | null)[], 
    feedback: DiagnosticFeedback
): Promise<void> => {
    if (!isSupabaseConfigured || !supabase) return;
    const user = await getCurrentUser();

    const { error } = await supabase
        .from('skill_diagnostics')
        .insert({
            user_id: user.id,
            skill: skill,
            questions: questions,
            user_answers: userAnswers,
            feedback: feedback
        });
    
    if (error) {
        console.error("Error saving skill diagnostic:", error);
        throw new Error(error.message);
    }
};
