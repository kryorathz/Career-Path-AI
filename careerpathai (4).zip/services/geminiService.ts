import { GoogleGenAI, Type, Chat } from "@google/genai";
import type { ResumeAnalysis, SkillQuestion, DiagnosticFeedback, JobRecommendation, CourseRecommendation, ResumeEvaluation, GroundingChunk, Opportunity, ImprovementPlan } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

// Utility to convert File to a GenerativePart
const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

const resumeSchema = {
    type: Type.OBJECT,
    properties: {
        name: { type: Type.STRING, description: "The full name of the candidate." },
        email: { type: Type.STRING, description: "The primary email address of the candidate." },
        phone: { type: Type.STRING, description: "The primary phone number of the candidate." },
        summary: { type: Type.STRING, description: "A professional summary of the candidate based on the resume." },
        skills: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of technical and soft skills." },
        experience: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    role: { type: Type.STRING },
                    company: { type: Type.STRING },
                    duration: { type: Type.STRING },
                    description: { type: Type.STRING, description: "A brief summary of responsibilities and achievements." }
                },
                required: ["role", "company", "duration", "description"]
            }
        },
        education: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    degree: { type: Type.STRING },
                    institution: { type: Type.STRING },
                    year: { type: Type.STRING }
                },
                required: ["degree", "institution", "year"]
            }
        },
        projects: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING },
                    description: { type: Type.STRING }
                },
                required: ["name", "description"]
            }
        },
        feedback: { type: Type.STRING, description: "Constructive feedback on how to improve the resume for ATS and human readers." }
    },
    required: ["name", "email", "phone", "summary", "skills", "experience", "education", "projects", "feedback"]
};


export const analyzeResume = async (file: File): Promise<ResumeAnalysis> => {
  try {
    const imagePart = await fileToGenerativePart(file);
    const textPart = { text: "Analyze this resume. Extract the candidate's contact information (name, email, phone) and all other key information. Provide feedback for improvement. Ensure the output is a valid JSON object matching the provided schema." };

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: resumeSchema
      }
    });

    const jsonString = response.text.trim();
    return JSON.parse(jsonString) as ResumeAnalysis;
  } catch (error) {
    console.error("Error analyzing resume:", error);
    throw new Error("Failed to analyze resume. Please try again.");
  }
};

const improvementPlanSchema = {
    type: Type.OBJECT,
    properties: {
        suggestions: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    type: { type: Type.STRING, description: "The type of suggestion: 'Project', 'Internship', or 'Course'." },
                    title: { type: Type.STRING, description: "A catchy title for the suggestion." },
                    description: { type: Type.STRING, description: "A brief explanation of why this suggestion is valuable and what it entails." }
                },
                required: ["type", "title", "description"]
            }
        }
    },
    required: ["suggestions"]
};

export const generateImprovementPlan = async (analysis: ResumeAnalysis): Promise<ImprovementPlan> => {
    try {
        const prompt = `
        You are a senior career coach. Based on the following resume analysis, identify the top 3 weaknesses or areas for improvement. 
        For each weakness, suggest a specific, actionable item like a project, an internship, or an online course to address it.
        Frame these as a "Resume Improvement Plan". For example, if a skill is missing, suggest a course. If there's a lack of practical experience, suggest a project.
        
        Resume Analysis:
        ${JSON.stringify(analysis, null, 2)}

        Respond with a valid JSON object matching the provided schema.
        `;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: improvementPlanSchema
            }
        });

        const jsonString = response.text.trim();
        return JSON.parse(jsonString) as ImprovementPlan;
    } catch (error) {
        console.error("Error generating improvement plan:", error);
        throw new Error("Failed to generate an improvement plan. Please try again.");
    }
};


const questionsSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswer: { type: Type.STRING }
        },
        required: ["question", "options", "correctAnswer"]
    }
};

export const generateSkillQuestions = async (skill: string, count: number = 5): Promise<SkillQuestion[]> => {
    try {
        const prompt = `Generate ${count} multiple-choice questions to test proficiency in ${skill}. The questions should cover beginner to intermediate concepts. Ensure the output is a valid JSON array matching the provided schema. Each question should have 4 options.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: questionsSchema
            }
        });

        const jsonString = response.text.trim();
        return JSON.parse(jsonString) as SkillQuestion[];
    } catch (error) {
        console.error("Error generating skill questions:", error);
        throw new Error("Failed to generate skill questions. Please try again.");
    }
};


const feedbackSchema = {
    type: Type.OBJECT,
    properties: {
        score: { type: Type.NUMBER, description: "A score out of 100 based on the number of correct answers." },
        feedback: { type: Type.STRING, description: "Overall feedback and suggestions for improvement based on the user's answers." },
        correctAnswers: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    question: { type: Type.STRING },
                    answer: { type: Type.STRING }
                },
                required: ["question", "answer"]
            }
        }
    },
    required: ["score", "feedback", "correctAnswers"]
};

export const evaluateAnswers = async (questions: SkillQuestion[], userAnswers: (string | null)[]): Promise<DiagnosticFeedback> => {
    try {
        const prompt = `
        A user has taken a skill test. Evaluate their answers and provide a score and constructive feedback.
        
        Questions and Correct Answers:
        ${questions.map(q => `- Question: "${q.question}"\n  - Correct Answer: "${q.correctAnswer}"`).join('\n')}
        
        User's Answers:
        ${questions.map((q, i) => `- Question: "${q.question}"\n  - User's Answer: "${userAnswers[i] || 'Not Answered'}"`).join('\n')}
        
        Please provide the evaluation as a JSON object matching the schema. Calculate the score as (correct_answers / total_questions) * 100. The feedback should be encouraging and point to areas of improvement.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: feedbackSchema
            }
        });

        const jsonString = response.text.trim();
        return JSON.parse(jsonString) as DiagnosticFeedback;
    } catch (error) {
        console.error("Error evaluating answers:", error);
        throw new Error("Failed to evaluate answers. Please try again.");
    }
};


export const getRecommendations = async (skills: string[], skillGaps: string[]): Promise<{ jobs: JobRecommendation[], courses: CourseRecommendation[] }> => {
    try {
        const prompt = `
            Based on the user's current skills and identified skill gaps, generate a list of 3 relevant job recommendations and 3 course recommendations.
            
            Current Skills: ${skills.join(', ')}
            Skill Gaps to address: ${skillGaps.join(', ')}

            The job recommendations should be for entry-level or junior roles. The courses should directly address the skill gaps.
            Provide a realistic match percentage for jobs.
            Ensure the output is a valid JSON object matching the provided schema.
        `;
        const recommendationSchema = {
            type: Type.OBJECT,
            properties: {
                jobs: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            title: { type: Type.STRING },
                            company: { type: Type.STRING },
                            location: { type: Type.STRING },
                            description: { type: Type.STRING, description: "A brief, compelling description of the role." },
                            matchPercentage: { type: Type.NUMBER, description: "A calculated percentage of how well the user's skills match the job." },
                            url: { type: Type.STRING, description: "A direct link to the job application page." }
                        },
                        required: ["title", "company", "location", "description", "matchPercentage", "url"]
                    }
                },
                courses: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            title: { type: Type.STRING },
                            provider: { type: Type.STRING, description: "e.g., Coursera, Udemy, LinkedIn Learning" },
                            skills: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Skills this course will teach." },
                            url: { type: Type.STRING, description: "A direct link to the course page." }
                        },
                        required: ["title", "provider", "skills", "url"]
                    }
                }
            },
            required: ["jobs", "courses"]
        };
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: recommendationSchema
            }
        });

        const jsonString = response.text.trim();
        return JSON.parse(jsonString) as { jobs: JobRecommendation[], courses: CourseRecommendation[] };
    } catch (error) {
        console.error("Error getting recommendations:", error);
        throw new Error("Failed to get recommendations. Please try again.");
    }
}

const resumeEvaluationSchema = {
    type: Type.OBJECT,
    properties: {
        score: { type: Type.NUMBER, description: "An 'ATS Score' from 0-100 based on keyword optimization, formatting, and standard conventions." },
        suggestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of 3-5 specific, actionable suggestions for improvement." }
    },
    required: ["score", "suggestions"]
};

export const evaluateResumeContent = async (resumeData: Partial<ResumeAnalysis>): Promise<ResumeEvaluation> => {
    try {
        const prompt = `
        You are an expert resume reviewer and career coach. Analyze the following resume content provided as a JSON object.
        Provide an 'ATS Score' from 0 to 100 based on keyword optimization, clarity, action verbs, and standard resume conventions.
        Also, provide a list of 3-5 specific, actionable suggestions for improvement.
        
        Resume Content:
        ${JSON.stringify(resumeData, null, 2)}

        Respond in the required JSON format.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: resumeEvaluationSchema
            }
        });

        const jsonString = response.text.trim();
        return JSON.parse(jsonString) as ResumeEvaluation;
    } catch (error) {
        console.error("Error evaluating resume content:", error);
        throw new Error("Failed to evaluate resume. Please try again.");
    }
}

const resumePointImprovementSchema = {
    type: Type.OBJECT,
    properties: {
        suggestions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of 2-3 improved versions of the resume bullet point."
        }
    },
    required: ["suggestions"]
};

export const improveResumePoint = async (text: string): Promise<{suggestions: string[]}> => {
    try {
        const prompt = `
        You are an expert resume reviewer. Rewrite the following resume description/bullet point to be more impactful.
        Use strong action verbs, quantify results where possible, and keep it concise. Provide 2-3 alternative suggestions.

        Original text: "${text}"

        Respond with a JSON object containing the suggestions.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: resumePointImprovementSchema
            }
        });

        const jsonString = response.text.trim();
        return JSON.parse(jsonString) as {suggestions: string[]};
    } catch (error) {
        console.error("Error improving resume point:", error);
        throw new Error("Failed to generate suggestions. Please try again.");
    }
}


// AI Career Coach Chat
let aiCoachChat: Chat | null = null;
const getAICoachChat = (): Chat => {
    if (!aiCoachChat) {
        aiCoachChat = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: `You are "CompetencyAI Coach", a friendly and professional AI career coach. Your goal is to help users with career planning, interview preparation, and skill development.
                - Keep your responses concise, encouraging, and actionable.
                - If asked to start a mock interview, ask for the role they're preparing for and then ask one question at a time.
                - Provide constructive feedback.
                - Never break character.
                `,
            },
        });
    }
    return aiCoachChat;
}

export async function* getAICoachResponseStream(message: string): AsyncGenerator<string> {
    try {
        const chatInstance = getAICoachChat();
        const responseStream = await chatInstance.sendMessageStream({ message });
        for await (const chunk of responseStream) {
            yield chunk.text;
        }
    } catch (error) {
        console.error("Error getting AI coach stream response:", error);
        throw new Error("The AI coach is currently unavailable. Please try again later.");
    }
}

// AI Skill Tutor Chat
let skillTutorChat: Chat | null = null;
const getSkillTutorChat = (): Chat => {
    if (!skillTutorChat) {
        skillTutorChat = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: `You are an AI Tutor. A user is taking a skills quiz and has asked for help. Your role is to explain the concepts related to their question to help them learn.
                - DO NOT give them the direct answer to the question.
                - Guide them towards the answer by explaining the underlying principles.
                - Be encouraging and supportive.
                `,
            },
        });
    }
    return skillTutorChat;
}

export async function* getSkillTutorResponseStream(message: string): AsyncGenerator<string> {
    try {
        const chatInstance = getSkillTutorChat();
        const responseStream = await chatInstance.sendMessageStream({ message });
        for await (const chunk of responseStream) {
            yield chunk.text;
        }
    } catch (error) {
        console.error("Error getting AI tutor stream response:", error);
        throw new Error("The AI tutor is currently unavailable. Please try again later.");
    }
}


// Career Hub Chat with Google Search
export const getCareerHubResponse = async (message: string): Promise<{summary: string, opportunities: Opportunity[], sources: GroundingChunk[]}> => {
    try {
        const prompt = `
            You are a helpful career assistant. The user is looking for opportunities. Use Google Search to find relevant, up-to-date jobs, internships, or online courses based on their request.
            User's request: "${message}"

            Respond with a single, valid JSON object only, with no other text before or after it.
            The JSON object must have two keys:
            1. "summary": A string containing a friendly and brief summary of the findings.
            2. "opportunities": An array of objects, where each object represents a job, internship, or course and has the following keys:
               - "type": A string, either "Job", "Internship", or "Course".
               - "title": A string for the job title or course name.
               - "companyOrProvider": A string for the company name or course provider.
               - "location": A string for the location (or "Remote" / "Online"). Can be null for courses.
               - "details": A short string with key details (e.g., "Full-time", "Paid", "Free").
               - "url": A string containing a direct URL to the opportunity.
            
            If you cannot find relevant opportunities, return an empty "opportunities" array and explain why in the summary.
        `;

        const response = await ai.models.generateContent({
           model: "gemini-2.5-flash",
           contents: prompt,
           config: {
             tools: [{googleSearch: {}}],
           },
        });

        const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] || [];
        
        try {
            // The response text from a model with grounding can sometimes have markdown formatting.
            // We need to find the JSON block within the string.
            const jsonMatch = response.text.match(/```json\n([\s\S]*?)\n```/);
            const jsonString = jsonMatch ? jsonMatch[1] : response.text;
            const parsedJson = JSON.parse(jsonString);
            return { ...parsedJson, sources };
        } catch (e) {
             console.error("Failed to parse JSON response from AI:", e);
             // Fallback for non-JSON or malformed JSON responses
             return {
                 summary: "I found some information but couldn't structure it properly. Here's the raw text:\n\n" + response.text,
                 opportunities: [],
                 sources: sources
             };
        }

    } catch (error) {
        console.error("Error getting Career Hub response:", error);
        throw new Error("Failed to fetch opportunities. Please check your connection and try again.");
    }
}